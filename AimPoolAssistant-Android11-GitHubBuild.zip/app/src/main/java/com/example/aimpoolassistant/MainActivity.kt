package com.example.aimpoolassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestOverlay = 4001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 40)
        }
        layout.addView(TextView(this).apply {
            text = "AimPool Assistant"
            textSize = 25f
        })
        layout.addView(TextView(this).apply {
            text = "Starter overlay untuk Android. Buka 8 Ball Pool, lalu gunakan tombol melayang untuk membuka panel alat."
            textSize = 16f
            setPadding(0, 18, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "Aktifkan tombol melayang"
            setOnClickListener { enableOverlay() }
        })
        layout.addView(TextView(this).apply {
            text = "\nCatatan: versi awal ini menyediakan overlay dan kalkulator sudut sederhana. Deteksi bola otomatis belum tersedia."
            textSize = 13f
        })
        setContentView(layout)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, requestOverlay)
        } else {
            startOverlay()
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay) {
            if (Settings.canDrawOverlays(this)) startOverlay()
            else Toast.makeText(this, "Izin tampil di atas aplikasi belum diberikan", Toast.LENGTH_LONG).show()
        }
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Tombol melayang aktif", Toast.LENGTH_SHORT).show()
    }
}
