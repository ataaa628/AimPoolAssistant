package com.example.aimpoolassistant

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.atan2
import kotlin.math.roundToInt

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun params(width: Int, height: Int) = WindowManager.LayoutParams(
        width, height, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 24
        y = 240
    }

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "A"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(20, 145, 119))
                setStroke(3, Color.WHITE)
            }
            setOnClickListener { togglePanel() }
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f
                var downY = 0f
                var startX = 0
                var startY = 0
                var moved = false
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = event.rawX; downY = event.rawY
                            startX = lp.x; startY = lp.y; moved = false
                            return false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - downX).roundToInt()
                            val dy = (event.rawY - downY).roundToInt()
                            if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                            if (moved) {
                                lp.x = startX + dx; lp.y = startY + dy
                                windowManager.updateViewLayout(v, lp)
                            }
                            return moved
                        }
                    }
                    return false
                }
            })
        }
        bubble = view
        windowManager.addView(view, params(58, 58))
    }

    private fun togglePanel() {
        if (panel != null) {
            windowManager.removeView(panel)
            panel = null
            return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = GradientDrawable().apply {
                setColor(Color.rgb(24, 29, 35))
                cornerRadius = 22f
                setStroke(2, Color.rgb(54, 199, 165))
            }
        }
        root.addView(TextView(this).apply {
            text = "AIMPOOL  •  ASSISTANT"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(90, 230, 195))
        })
        root.addView(TextView(this).apply {
            text = "Alat bantu latihan"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, 4, 0, 12)
        })
        val angleLabel = TextView(this).apply {
            text = "Sudut: —"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
        }
        root.addView(angleLabel)
        root.addView(Button(this).apply {
            text = "Hitung sudut contoh (30°, 45°, 60°)"
            setOnClickListener {
                val angle = atan2(1.0, 1.0) * 180.0 / Math.PI
                angleLabel.text = "Sudut contoh: ${angle.roundToInt()}°"
            }
        })
        root.addView(TextView(this).apply {
            text = "Deteksi posisi bola otomatis dan garis bidik di atas meja belum diimplementasikan pada versi awal."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 10)
        })
        root.addView(Button(this).apply {
            text = "Tutup panel"
            setOnClickListener { togglePanel() }
        })
        panel = root
        windowManager.addView(root, params(290, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = 96
            y = 260
        })
    }

    override fun onDestroy() {
        panel?.let { windowManager.removeView(it) }
        bubble?.let { windowManager.removeView(it) }
        panel = null
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_STICKY
}
