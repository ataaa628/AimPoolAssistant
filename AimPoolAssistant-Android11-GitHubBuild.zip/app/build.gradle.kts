plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.aimpoolassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.aimpoolassistant"
        minSdk = 23
        targetSdk = 30
        versionCode = 1
        versionName = "0.1"
    }
}
