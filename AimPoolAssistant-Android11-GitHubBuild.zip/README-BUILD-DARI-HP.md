# AimPool Assistant — Android 11 / build via browser

Proyek awal Android native (Kotlin). Cocok sebagai starter untuk HP Android 11.
Belum merupakan AimKing clone penuh: deteksi posisi bola otomatis, pengenalan meja,
dan garis bidik yang mengikuti bola belum dibuat.

## Cara membuat APK tanpa memasang IDE di HP

Kamu memerlukan akun GitHub. Build dilakukan di server GitHub Actions, bukan di HP.

1. Buka https://github.com di browser HP dan masuk/daftar akun.
2. Buat repository baru bernama `AimPoolAssistant` (boleh Public atau Private).
3. Ekstrak ZIP ini dengan pengelola file HP.
4. Upload seluruh isi folder proyek ke repository. Pastikan folder `.github/workflows`
   ikut terunggah dan file workflow berada di `.github/workflows/build-apk.yml`.
5. Buka tab **Actions** pada repository.
6. Jika diminta, pilih **I understand my workflows, go ahead and enable them**.
7. Pilih workflow **Build Android APK**, tekan **Run workflow**.
8. Tunggu sampai proses selesai dengan tanda centang hijau.
9. Buka hasil run, cari bagian **Artifacts**, lalu unduh `AimPoolAssistant-debug-apk`.
10. Ekstrak ZIP artifact dan temukan `app-debug.apk`.

## Izin overlay di Android 11

Setelah APK terpasang:
1. Buka AimPool Assistant.
2. Tekan tombol untuk mengaktifkan tombol melayang.
3. Android akan membuka pengaturan "Tampil di atas aplikasi lain".
4. Izinkan untuk AimPool Assistant.
5. Kembali ke aplikasi, lalu buka 8 Ball Pool untuk menguji tombol overlay.

## Keamanan dan batasan

- APK debug ditandatangani dengan debug key build server; ini bukan rilis Play Store.
- Jangan mengaktifkan izin Accessibility atau memasang APK dari sumber tidak dikenal yang tidak dipercaya.
- APK starter hanya menampilkan floating bubble dan panel kalkulator contoh.
- Tidak membaca layar game, tidak mengubah game, dan tidak melakukan auto-aim.
- Untuk menghindari salah paham: belum ada jaminan kompatibilitas atau persetujuan dari 8 Ball Pool.
