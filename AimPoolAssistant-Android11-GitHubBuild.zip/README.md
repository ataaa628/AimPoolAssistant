# AimPool Assistant — starter project

Proyek Android native (Kotlin) untuk membuat tombol melayang dan panel alat bantu latihan saat 8 Ball Pool terbuka.

## Yang sudah ada
- Aplikasi Android sederhana.
- Permintaan izin `Tampil di atas aplikasi`.
- Tombol overlay bulat yang bisa digeser.
- Panel overlay yang bisa dibuka/tutup.
- Contoh kalkulasi sudut sederhana.

## Yang belum ada
- Pengenalan bola otomatis dari layar.
- Deteksi meja dan koordinat bola.
- Garis bidik/pantulan yang mengikuti posisi bola.
- APK hasil build dan pengujian pada perangkat nyata.

Jadi ini **starter project**, bukan pengganti AimKing yang sudah lengkap.

## Membuka proyek
1. Instal Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Android Studio → Open → pilih folder `AimPoolAssistant`.
4. Tunggu Gradle Sync.
5. Hubungkan HP Android dengan USB debugging aktif.
6. Tekan Run.

Target SDK 30 dan minimum SDK 23. Android Studio mungkin meminta SDK platform 35 dan JDK 17.

## Menguji overlay
1. Jalankan aplikasi.
2. Tekan "Aktifkan tombol melayang".
3. Izinkan "Tampil di atas aplikasi lain".
4. Buka 8 Ball Pool. Tombol hijau `A` seharusnya tetap terlihat.
5. Ketuk tombol untuk membuka panel; geser tombol untuk memindahkannya.

## Catatan
Aplikasi ini tidak memodifikasi file game, tidak melakukan input otomatis, dan tidak menjamin kompatibilitas dengan kebijakan 8 Ball Pool. Gunakan hanya sebagai alat bantu latihan.
